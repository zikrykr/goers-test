<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=a, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Goers Test</title>
    <style>
        body{
            margin: 0;
            padding: 2em;
        }

        ul > li{
            padding: 0.5em;
        }
    </style>
</head>
<body>
    <h3>List of Projects</h3>
    <ul>
        <li><a href="multiple-of-3-and-5/view/">Multiple of 3 and 5</a></li>
        <li><a href="even-fibonacci-numbers/view/">Even Fibonacci Numbers</a></li>
        <li><a href="largest-product-in-a-series/view/">Largest product in a series</a></li>
        <li><a href="large-sum/view/">Large Sum</a></li>
        <li><a href="10001st-prime/view/">10001st Prime</a></li>
    </ul>
</body>
</html>