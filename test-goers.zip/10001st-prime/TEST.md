# How To Run Unit Test

1. Open this [url](http://localhost/test-goers/10001st-prime/test/test.php) at your browser
2. Input the limit range in form and click submit button to see the result.

## Limit Range Examples and Expected Output

1. Limit range: 9, Output: 23
2. Limit range: 300, Output: 1987
3. Limit Range: 414, Output: 2851
4. Limit Range: 636, Output: 4721
5. Limit Range: 710, Output: 5387
6. Limit Range: 825, Output: 6337
