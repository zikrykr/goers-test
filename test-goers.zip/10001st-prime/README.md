# 10001st Prime

---

## Description

> This source code provide the solution for the following problems.

**By listing the first six prime numbers: 2, 3, 5, 7, 11, and 13, we can see that the 6th prime is 13.**

**What is the 10 001st prime number?**

---

## Usage/ Installation

1. Install XAMPP for [Windows](https://downloadsapachefriends.global.ssl.fastly.net/5.6.40/xampp-win32-5.6.40-0-VC11-installer.exe?from_af=trueXampp)
   or [Linux](https://downloadsapachefriends.global.ssl.fastly.net/5.6.40/xampp-linux-x64-5.6.40-0-installer.run?from_af=true).
   You can click [this link (for Windows users)](https://www.wikihow.com/Install-XAMPP-for-Windows) or [this link (for Linux users)](https://www.wikihow.com/Install-XAMPP-on-Linux) for installation guidance.
2. Clone or Download this project files.
3. Extract the .zip files to htdocs folder on XAMPP Installation directory (C:/xampp/htdocs).
4. Open XAMPP Control Panel.
5. Start Apache Server.
6. Open this [url](http://localhost/test-goers/10001st-prime/view/) at your browser
