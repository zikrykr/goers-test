# How To Run Unit Test

1. Open this [url](http://localhost/test-goers/even-fibonacci-numbers/test/test.php) at your browser
2. Input the max value in form and click submit button to see the result.

## Limit Range Examples and Expected Output

1. Limit range: 9, Output: 10
2. Limit range: 300, Output: 188
3. Limit Range: 414, Output: 798
4. Limit Range: 300000, Output: 257114
5. Limit Range: 900000, Output: 1089154
6. Limit Range: 3000000, Output: 4613732
