# How To Run Unit Test

1. Open this [url](http://localhost/test-goers/large-sum/test/test.php) at your browser
2. Input the max value in form and click submit button to see the result.

## Limit Range Examples and Expected Output

1. Limit range: 6, Output: 553737
2. Limit range: 8, Output: 55373762
3. Limit Range: 11, Output: 55373762303
4. Limit Range: 14, Output: 55373762303908
5. Limit Range: 16, Output: 5537376230390876
6. Limit Range: 17, Output: 55373762303908766
