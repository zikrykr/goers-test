<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Large Sum</title>
    <style>
        body{
            margin: 0;
            padding: 2em;
        }
    </style>
</head>
<body>
    <a href="../../index.php">Go Back To Home</a>
    <h3>Large Sum</h3>
    <p>Output: </p>
    <?php 
        include_once('../controller/controller.php');
        //function
        getSumDigitsRange(10);
    ?>
</body>
</html>