# How To Run Unit Test

1. Open this [url](http://localhost/test-goers/multiple-of-3-and-5/test/test.php) at your browser
2. Input the max number in form and click submit button to see the result.

## Limit Range Examples and Expected Output

1. Limit range: 1100, Output: 281418
2. Limit range: 2345, Output: 1281153
3. Limit Range: 3310, Output: 2555873
4. Limit Range: 4500, Output: 4722750
5. Limit Range: 5300, Output: 6549918
6. Limit Range: 7800, Output: 14192100
