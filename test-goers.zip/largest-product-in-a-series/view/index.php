<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Largest Product in A Series</title>
    <style>
        body{
            margin: 0;
            padding: 2em;
        }
    </style>
</head>
<body>
    <a href="../../index.php">Go Back To Home</a>
    <h3>Largest Product in A Series</h3>
    <p>Output: </p>
    <?php 
        include_once('../controller/controller.php');
        //function
        getProduct(13);
    ?>
</body>
</html>