# How To Run Unit Test

1. Open this [url](http://localhost/test-goers/largest-product-in-a-series/test/test.php) at your browser
2. Input the max value in form and click submit button to see the result.

## Limit Range Examples and Expected Output

1. Limit range: 6, Output: 285768
2. Limit range: 8, Output: 7838208
3. Limit Range: 11, Output: 940584960
4. Limit Range: 14, Output: 70573265280
5. Limit Range: 16, Output: 1693758366720
6. Limit Range: 17, Output: 5292994896000
