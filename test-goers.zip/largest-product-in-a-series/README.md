# Even Fibonacci Numbers

---

## Description

> This source code provide the solution for the following problems.

**Work out the first ten digits of the sum of the following one-hundred 50-digit numbers.**

---

## Usage/ Installation

1. Install XAMPP for [Windows](https://downloadsapachefriends.global.ssl.fastly.net/5.6.40/xampp-win32-5.6.40-0-VC11-installer.exe?from_af=trueXampp)
   or [Linux](https://downloadsapachefriends.global.ssl.fastly.net/5.6.40/xampp-linux-x64-5.6.40-0-installer.run?from_af=true).
   You can click [this link (for Windows users)](https://www.wikihow.com/Install-XAMPP-for-Windows) or [this link (for Linux users)](https://www.wikihow.com/Install-XAMPP-on-Linux) for installation guidance.
2. Clone or Download this project files.
3. Extract the .zip files to htdocs folder on XAMPP Installation directory (C:/xampp/htdocs).
4. Open XAMPP Control Panel.
5. Start Apache Server.
6. Open this [url](http://localhost/test-goers/largest-product-in-a-series/view/) at your browser
